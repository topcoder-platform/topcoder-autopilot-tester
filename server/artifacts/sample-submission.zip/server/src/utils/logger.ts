
import EventEmitter from 'eventemitter3';

export type LogEvent = { level: 'info' | 'warn' | 'error' ; message: string; data?: any; progress?: number };

export class RunnerLogger extends EventEmitter {
  log(level: LogEvent['level'], message: string, data?: any, progress?: number) {
    this.emit('log', { level, message, data, progress } as LogEvent);
  }
  info(message: string, data?: any, progress?: number) { this.log('info', message, data, progress); }
  warn(message: string, data?: any, progress?: number) { this.log('warn', message, data, progress); }
  error(message: string, data?: any, progress?: number) { this.log('error', message, data, progress); }
}
