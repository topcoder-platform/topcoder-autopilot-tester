
import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { RunnerLogger } from '../utils/logger.js';
import { runFlow, type FlowConfig, type StepName } from '../services/flowRunner.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataPath = path.resolve(__dirname, '../../data/config.json');

const router = Router();

router.get('/stream', async (req, res) => {
  const mode = (req.query.mode || 'full') as 'full' | 'toStep';
  const toStep = req.query.toStep as StepName | undefined;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  function send(evt: any) {
    res.write(`data: ${JSON.stringify(evt)}\n\n`);
  }

  const log = new RunnerLogger();
  log.on('log', (e) => send(e));

  let cfg: FlowConfig;
  try {
    cfg = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
  } catch (e) {
    send({ level: 'error', message: 'Failed to read config' });
    res.end();
    return;
  }

  try {
    send({ level: 'info', message: 'Run started' });
    await runFlow(cfg, mode, toStep, log);
    send({ level: 'info', message: 'Run finished', progress: 100 });
  } catch (e: any) {
    send({ level: 'error', message: 'Run failed', data: e?.message || String(e) });
  } finally {
    res.end();
  }
});

export default router;
