
import { Router } from 'express';
import { getToken, axiosWithAuth } from '../services/topcoder.js';

const router = Router();

router.get('/challenge-types', async (req, res) => {
  try {
    const token = await getToken();
    const ax = axiosWithAuth(token);
    const { data } = await ax.get('https://api.topcoder-dev.com/v6/challenge-types');
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: 'Failed to fetch challenge types', details: e?.message || String(e) });
  }
});

router.get('/challenge-tracks', async (req, res) => {
  try {
    const token = await getToken();
    const ax = axiosWithAuth(token);
    const { data } = await ax.get('https://api.topcoder-dev.com/v6/challenge-tracks');
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: 'Failed to fetch challenge tracks', details: e?.message || String(e) });
  }
});

router.get('/scorecards', async (req, res) => {
  try {
    const { challengeType, challengeTrack } = req.query;
    const token = await getToken();
    const ax = axiosWithAuth(token);
    const { data } = await ax.get(`https://api.topcoder-dev.com/v6/scorecards`, { params: { challengeType, challengeTrack } });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: 'Failed to fetch scorecards', details: e?.message || String(e) });
  }
});

export default router;
