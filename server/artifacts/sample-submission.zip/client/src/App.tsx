
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import ConfigTable from './components/ConfigTable'
import ConfigForm from './components/ConfigForm'
import Runner from './components/Runner'

export default function App() {
  const [config, setConfig] = useState<any>(null);
  const [view, setView] = useState<'home'|'edit'|'runFull'|'runToStep'>('home');
  const [toStep, setToStep] = useState<string>('activate');

  const loadConfig = async () => {
    const { data } = await axios.get('/api/config');
    setConfig(data);
  };
  useEffect(()=>{ loadConfig() }, []);

  if (!config) return <div className="container"><div className="card">Loading...</div></div>;

  return (
    <div className="container">
      <div className="row" style={{marginBottom: 16}}>
        <div className="col"><ConfigTable config={config} /></div>
      </div>
      <div className="row" style={{marginBottom: 16}}>
        <div className="col">
          <div className="card">
            <h3>Actions</h3>
            <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
              <button onClick={()=>setView('runFull')}>Run the full flow</button>
              <button onClick={()=>setView('runToStep')}>Run to a specific step</button>
              <button className="secondary" onClick={()=>setView('edit')}>Edit configuration</button>
            </div>
          </div>
        </div>
      </div>

      {view==='edit' && <ConfigForm onSaved={()=>{ loadConfig(); setView('home'); }} />}
      {view==='runFull' && <Runner mode="full" />}
      {view==='runToStep' && (
        <div className="card">
          <label>Step</label>
          <select value={toStep} onChange={e=>setToStep(e.target.value)} style={{maxWidth:400, marginBottom: 12}}>
            {['token','createChallenge','updateDraft','activate','awaitRegSubOpen','assignResources','createSubmissions','awaitReviewOpen','createReviews','awaitAppealsOpen','createAppeals','awaitAppealsResponseOpen','appealResponses','awaitAllClosed','awaitCompletion'].map(s=>(
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <Runner mode="toStep" toStep={toStep} />
        </div>
      )}
    </div>
  )
}
