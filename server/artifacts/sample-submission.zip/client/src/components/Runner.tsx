
import React, { useEffect, useRef, useState } from 'react'

export default function Runner({ mode, toStep }: { mode: 'full'|'toStep', toStep?: string }) {
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<{level:string,message:string,data?:any,progress?:number}[]>([]);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(()=>{
    if (!running) return;
    const params = new URLSearchParams({ mode });
    if (toStep) params.set('toStep', toStep);
    const es = new EventSource(`/api/run/stream?${params.toString()}`);
    es.onmessage = (ev) => {
      try {
        const data = JSON.parse(ev.data);
        setLogs(prev => [...prev, data]);
        if (typeof data.progress === 'number') setProgress(data.progress);
        logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
      } catch {}
    };
    es.onerror = () => { es.close(); setRunning(false); };
    return () => es.close();
  }, [running, mode, toStep]);

  return (
    <div className="card">
      <h3>Run</h3>
      <div className="progress" style={{marginBottom: 8}}><div className="bar" style={{ width: progress+'%' }} /></div>
      <div style={{display:'flex', gap:8, marginBottom: 8}}>
        <button disabled={running} onClick={()=>setRunning(true)}>{running ? 'Running...' : 'Start'}</button>
        <button className="secondary" disabled={!running} onClick={()=>setRunning(false)}>Stop Stream</button>
        <span className="pill">{progress}%</span>
      </div>
      <div ref={logRef} className="log">
        {logs.map((l,i)=>(
          <div key={i}>
            <span>[{l.level.toUpperCase()}]</span> {l.message} {l.data ? <pre style={{display:'inline', marginLeft:6}}>{JSON.stringify(l.data)}</pre> : null}
          </div>
        ))}
      </div>
    </div>
  )
}
