
import React from 'react'

export default function ConfigTable({ config }: { config: any }) {
  return (
    <div className="card">
      <h3>Current Configuration</h3>
      <table>
        <tbody>
          <tr><th>Challenge name prefix</th><td>{config.challengeNamePrefix}</td></tr>
          <tr><th>Project ID</th><td>{config.projectId}</td></tr>
          <tr><th>Challenge Type ID</th><td>{config.challengeTypeId}</td></tr>
          <tr><th>Challenge Track ID</th><td>{config.challengeTrackId}</td></tr>
          <tr><th>Timeline Template ID</th><td>{config.timelineTemplateId}</td></tr>
          <tr><th>Copilot handle</th><td>{config.copilotHandle || '-'}</td></tr>
          <tr><th>Reviewers</th><td>{(config.reviewers||[]).join(', ') || '-'}</td></tr>
          <tr><th>Submitters</th><td>{(config.submitters||[]).join(', ') || '-'}</td></tr>
          <tr><th>Submissions per submitter</th><td>{config.submissionsPerSubmitter}</td></tr>
          <tr><th>Scorecard ID</th><td>{config.scorecardId}</td></tr>
          <tr><th>Prizes</th><td>{config.prizes?.join(', ')}</td></tr>
        </tbody>
      </table>
      <small className="pill">Note: M2M secrets are read from <code>server/secrets/m2m.json</code> and never sent to the browser.</small>
    </div>
  )
}
